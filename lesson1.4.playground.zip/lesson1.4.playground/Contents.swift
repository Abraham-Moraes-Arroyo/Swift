import UIKit


// Assign A value

/*
 Use the = operator to assign a vlaue. The name on the left is assigned the value on the right
 
 this code declares that "Luke: is your favorite person:
 */

let favoritePerson = "Luke"

// the = operator is also used to modify or reassign a value. The followign code delcares a shoeSize variable and assigns 8 as its value. The vale is then modified to 9:

var shoeSize = 8
shoeSize = 9 // Reassings shoeSize to 9


// baic arithmetic
/*
 you can use the +, -, *, / operatos to perform basic math functionality
 */

//var opponentScore = 3*8
//// opponentScore has a value of 24
//var myScore = 100/4
//// myScore has a value of 25

//  you cna use operators to perform arithmetic usign the alues of other variables

//var totalSocre = opponentScore + myScore // totalScore has the value of 49

// An operator can even reference the current variable, updating it to a new vlaue:

//myScore = myScore + 3 // Updates myScore to the current vlaue plus 3

//for decimal- point precision, you can do the same operatiosn on Double values:

let totalDistance = 3.9
var distanceTraveled = 1.2
var remainingDistance = totalDistance - distanceTraveled
// remainingDisntace  has a value of 2.7

// when you use the division operator (/) on Int values, the reesutl will be an Int value rounded to the nearest whole number, because Int type supports whole numbers:

//let x = 51
//let y = 4
//let z = x / y // z has a vlaue of 12

// if you explicitly declare constants or variables as Double values, the results will include decimal values.

//let x: Double = 51
//let y: Double = 4
//let z = x / y // z has a value of 12.75

//Compound Assigment
// An earlier code snippet udpated a variable adding a number to itself:

var myScore = 10
myScore = myScore + 3
// updates myScore to the current value plus 3

//but there's a better way to modify a vlaue that's already been assigned. You can use compound assigment operator, which adds the = operator after an aritmetic operator

myScore += 3//adds to myScore
myScore -= 5 // subtracts 5 from myScore
myScore *= 2 // multiplies myScore by 2
myScore /= 2 // Divides myScore by 2

// remainder Operator

//use the remainder operator (%) to quickly calculate ther reaminderdfrom the division  of two Int values

let dividend = 10
let divisor = 3
let quotient = dividend / divisor // quotient has a value of 3
let remainder = dividend  % divisor // remainder has a vlaue of 1


// you can calculare the reaminder as dividend- (quotient * divisor), but the remainder operator is eaiser faster, cleaner and more concise.

// Order of oeprators Mathematic operations always follow a specific order. Multiplication and division have priotrity over adiditon and subtraction, and parentheses have priority voer all four.
//consider the follwing variables
 var x = 2
var y = 3
var z = 5

//the consider the following calculations:

x + y * z // equals 17

(x + y) * z // equals 25


// in the first line above, multiplicaiton takes precedence over additon. in the second line, the parentheses get to do their work first.

//the reaminder operator has the same precedence as multiplication and division

y + z % // equals 4
(y + z ) % x // equals 0

/*
 if you are going to be adding a float with an int just make sure you have Double() on the variable that you made a float :
 
 let x = 3
 
 let y= 0.12
 
 let  pi = Double(x)+ y
 */
