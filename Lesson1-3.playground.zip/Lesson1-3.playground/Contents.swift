import UIKit

//
//let helloWorld = "Hello, world!"
//
//let helloPlayground = "Hello, playground!"
//
//let goodbyePlayground = "Goodbye, playground"
//
//print("Testing, testing, 1-2-3")
//



//When you want to name a vlaue that won't chang
//during the lifteim of the program you'll use a constant. you define constants in Swift using the ``let`` keyword.

//let name = "John"

//The code above creates a constant called ``name`` and assigns the value "John" to the constnat if you want to access that vlaue in later lines of code, you can use name to reference the constnat directly. This quick reference is especially helpful when you have one value that you want to use many times in a program.

//print(name)

// the code above printed "John" to the console. Because ``name`` is a constant, you can't give it a new value after assigning it. For example, the following code won't run:
// let name = "John"
//name "James"


//Variables

//When you want a to name a vlaue that may change during the lifetime of the app you'll use a variable. You defien tvariables usign the ``var`` keyword.

//var age = 29
//print(age) // this printed 29 to the console


//because age is a variable, you can ssign a new vlaue in later lines of code. The following code compiles with no errors.

//var age = 29
//
//age = 30
//
//print(age) // this prints 30 to the console.
//
//
//

//you can assign constants and vairabels from other constants and variables. This functinality is useful when you want to copy a vlaue to one or more other variabel.s

//let defaultScore = 100
//var playerOneScore = defaultScore
//var playerTwoScore = defaultScore
//
//print (playerOneScore)
//print (playerTwoScore)
//
//playerOneScore = 200
//print(playerOneScore)

/* Is the full comment */
// is the single line comment


//definition:

//In addition, yuc andefine your own types in Swift by creating a type definition. Consider a simple ``Person`` type:

struct Person{
    let firstName: String
    let lastName: String

    func sayHello(){
        print("hello there,may name is \(firstName) \(lastName).")
    }
}

//The example above describes how the type ``Person`` should look and perform. When you create a type and ssign it to a variable or constant, you're creating a version or instance of that type. Thus, an instance is a value. Consider the following code:
let aPerson = Person(firstName: "Jacob", lastName:"Edwards")
let anotherPerson = Person(firstName: "Candance", lastName: "Salinas")

aPerson.sayHello()
anotherPerson.sayHello()

//this ccode creates two instances of the ``Person`` type. Once instance represents a ``person`` named Jacob Edwards,a dn the other instance represents a person named Candace Salinas.

/* Type Safety
 swift is considerd a type-safe language. Type- safe means you need to be clear about your variables. For example if you code expects an INt, you can't pass it as a Double ro a String
 
 i.e.,
 
 let playerName= "Julian"
 
var playerScore= 1000
 
 var gameOver= fals e
 
 playerScore = playerName
 
 // will be flagged for mimatched types, will not compile.
 
 
// the same applies here
 
 
var wholeNumber= 30
 var numberWithDecimals 17.5
 
 wholeNumber= numberWithDecimals
 
 // will be flagged for mismatched types, will not compile.
 
 */


//working with large numbers

var largeUglyNumber = 100000

var largePrettyNumber = 1_000_000

//Type Inference

let cityName = "San Francisco"
// "San Francisco" is obviously  a `string`, so the compile automatically assigns the type of cityNae to a `string`.

let pi = 3.145927

// 3.145927 is a number with decimal points, so the compiler automatically assigns the type `pi` to a `Double`.

/*
 Once you assing a vlaue to a constant or a variable, the type is set and can't b e changed. this is true even for variables. the vlaue of a variable may change, but not its type.
 
 you might find cases wher it's usefil or even required, to explicity specify the tpye of a constant or variable. this is reffered to as a type annotation. to specify a type, add a Colon (:), a space, and the type name followign constant or variable name.

 */

let cityNames: String = "San Francisco"

let piNum:Double = 3.145927

//you can use a type annotation with differn number types. The Swift compiler will adjust to the value to match the type.

let number: Double = 3
print(number)

//Whenevery you define a constabnt or variable, you must eithre specify a type using a type annotation or asign it a value that the compiler cna use to infer the type.

//var x // this will result in an error

//Even when you use a type annotation, your code can't work with a constnat or variable if you haven't assign it a value

//var x : Int
//print (x)
//this will result in an error.

//once the vlaue is assigned the constant or variable becomes available

var x: Int
x = 10
print(x)
